#!/bin/sh
# Created by: Alexander Sepelenco 20335014, Niall Sauvage 20334203
scp $1@macneill.scss.tcd.ie:/users/ugrad/$1/Concurrency/output.txt .
