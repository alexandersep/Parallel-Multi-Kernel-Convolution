#!/bin/sh
scp $1@macneill.scss.tcd.ie:/users/ugrad/$1/Concurrency/output.txt .
